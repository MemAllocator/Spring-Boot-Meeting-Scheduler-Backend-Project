package com.exercise.MeetingScheduler.excpertions;

public class DateValidationException extends Exception {
    public DateValidationException(String errorMessage) {
        super(errorMessage);
    }
}
